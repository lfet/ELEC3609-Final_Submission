Dummy Accounts in Database:

Businesses Usernames:
Sydney_University-Tennis
SydneyCBD_SportCentre-LockerHire
Nationwide_Parking

Customer Usernames:
uni_student
sydney_worker
lfet7715

ALL HAVE PASSWORD '123lukey'

Sign in to View Bookings, Search for Bookings,
Create Booking Tables, Delete Bookings etc. . . .

