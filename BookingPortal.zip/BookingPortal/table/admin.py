from django.contrib import admin
from .models import Booking, Asset

admin.site.register(Booking)
admin.site.register(Asset)
